-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)
speed = 0


events.ENTITY_INIT:register(function()
    vanilla_model.PLAYER:setVisible(false)
end
)

function events.render(delta)
  speed = speed + 1
  models.model:color(math.abs(math.sin(math.rad(speed))),0,0)
  models.model.Skull:color(math.abs(math.sin(math.rad(speed))),0,0)
end

local anims = require("JimmyAnims")
anims(animations.model)

