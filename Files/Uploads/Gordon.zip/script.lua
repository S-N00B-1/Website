-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

function events.tick()
    local headrot = vanilla_model.HEAD:getOriginRot()
    models.model.Root.Face:setRot(headrot) 
end

local anims = require("JimmyAnims")
anims(animations.model)
