-- + Made by Jimmy Hellp
-- + V1 for 0.1.0
-- + Thank you GrandpaScout for helping with the library stuff!
-- + Automatically compatible with GSAnimBlend, you can change the blend times below (just don't change the file name)
------------------------ DON'T EDIT ANYTHING UNLESS YOU KNOW WHAT YOU'RE DOING ------------------------ 

local avatarVer = "0.1.0"
assert(
  client.compareVersions(client.getFiguraVersion(), avatarVer) > -1,
  "§4Your version of Figura is out of date for this animation template, the expected version is ".. avatarVer.." or newer"
)

local bbmodels = {}

local function errors(paths)
    assert(
        next(paths),
        "§4No blockbench models were found, or the blockbench model found contained no animations."
    )

    for _, path in pairs(paths) do
        for _, anim in pairs(path) do
            if anim:getName():find("%.") then
                error("§4The animation §b'"..anim:getName().."'§4 has a period ( . ) in its name, the handler can't use that animation and it must be renamed to fit the handler's accepted animation names. \n" ..
                "If the animation isn't meant for the handler, you can delete this line of code.")
            end
        end
    end
end


local hp = 20
local oldhp = 20

local handedness = false
local sleeping = false
local rightActive
local leftActive

local cFlying
local oldcFlying = cFlying
local flying = false
local flyTimer = 0

local dist
local oldDist = dist
local reach = 4.5
local reachTimer = 0

local targetEntity = false
local hitBlock

-- wait code from Manuel
local timers = {}
local function wait(ticks,next)
    table.insert(timers, {t=world.getTime()+ticks,n=next})
end
function events.tick()
    for key,timer in pairs(timers) do
        if world.getTime() >= timer.t then
            timer.n()
            table.remove(timers,key)
        end
    end
end

function events.entity_init()
    hp = player:getHealth() + player:getAbsorptionAmount()
    oldhp = hp
end

local function animInit(paths)
    for _, path in pairs(paths) do
        if path.attackR then path.attackR:priority(1.5) end
        if path.attackL then path.attackL:priority(1.5) end
    end
end

function pings.JimmyAnims_cFly(x)
    flying = x
end

function pings.JimmyAnims_Distance(x)
    reach = x
end

function pings.JimmyAnims_Attacking()
    if not player:isLoaded() then return end

    targetEntity = type(player:getTargetedEntity()) == "PlayerAPI" or type(player:getTargetedEntity()) == "LivingEntityAPI"
    hitBlock = not (next(player:getTargetedBlock(true,reach):getTextures()) == nil)
    wait(1, function()
        local rightSwing = player:getSwingArm() == rightActive and not sleeping
        local leftSwing = player:getSwingArm() == leftActive and not sleeping
        local rightMine = rightSwing and hitBlock and not targetEntity
        local leftMine = leftSwing and hitBlock and not targetEntity
        local rightAttack = rightSwing and not handedness and (not hitBlock or targetEntity)
        local leftAttack = leftSwing and handedness and (not hitBlock or targetEntity)

        for _, path in pairs(bbmodels) do
            if path.attackR and (not deadstate and rightAttack or (rightMine and not path.mineR)) then
                path.attackR:play()
                sounds:playSound("Attack", player:getPos(), 1, 1, false)
            end
            if path.attackL and (not deadstate and leftAttack or (leftMine and not path.mineL)) then
                path.attackL:play()
                sounds:playSound("Attack", player:getPos(), 1, 1, false)
            end
            if path.mineR and (not deadstate and rightMine) then
                path.mineR:play()
                sounds:playSound("Mine", player:getPos(), 1, 1, false)
            end
            if path.mineL and (not deadstate and leftMine) then
                path.mineL:play()
                sounds:playSound("Mine", player:getPos(), 1, 1, false)
            end
        end
    end)
end

function pings.JimmyAnims_Using()
    if not player:isLoaded() then return end
    
    wait(1,function()
        local rightSwing = player:getSwingArm() == rightActive and not sleeping
        local leftSwing = player:getSwingArm() == leftActive and not sleeping
    
        for _, path in pairs(bbmodels) do   

            if not (rightSwing or leftSwing) then
                sounds:playSound("UseFail", player:getPos(), 1, 1, false)
            elseif path.useR and (not deadstate and rightSwing) then
                path.useR:play()
                sounds:playSound("Use", player:getPos(), 1, 1, false)
            elseif path.attackR and not path.useR and (not deadstate and rightSwing) then
                path.attackR:play()
                sounds:playSound("Use", player:getPos(), 1, 1, false)
            end
            if path.useL and (not deadstate and leftSwing) then
                path.useL:play()
                sounds:playSound("Use", player:getPos(), 1, 1, false)
            elseif path.attackL and not path.useL and (not deadstate and leftSwing) then
                path.attackL:play()
                sounds:playSound("Use", player:getPos(), 1, 1, false)
            end
        end
    end)
end


local attack = keybinds:newKeybind("Attack",keybinds:getVanillaKey("key.attack"))
attack.press = function() pings.JimmyAnims_Attacking() end

local use = keybinds:newKeybind("Use",keybinds:getVanillaKey("key.use"))
use.press = function() pings.JimmyAnims_Using() end

local function tick()
    if host:isHost() then
        cFlying = host:isFlying()
        if cFlying ~= oldcFlying then
            pings.JimmyAnims_cFly(cFlying)
        end
        oldcFlying = cFlying

        flyTimer = flyTimer + 1
        if flyTimer % 200 == 0 then
            pings.JimmyAnims_cFly(cFlying)
        end

        dist = host:getReachDistance()
        if dist ~= oldDist then
            pings.JimmyAnims_Distance(dist)
        end
        oldDist = dist

        reachTimer = reachTimer + 1
        if reachTimer % 200 == 0 then
            pings.JimmyAnims_Distance(dist)
        end

    end

    local pos = player:getPos()

    local stairBlock = (world.getBlockState(pos-vec(0,.3,0)).id:find("stair") or world.getBlockState(pos-vec(0,.8,0)).id:find("stair") or world.getBlockState(pos-vec(0,1,0)).id:find("stair")) or false
    local slabBlock = (world.getBlockState(pos-vec(0,.5,0)).id:find("slab") or world.getBlockState(pos-vec(0,.6,0)).id:find("slab")) or false
    local slimeBlock = (world.getBlockState(pos-vec(0,.5,0)).id:find("slime" or world.getBlockState(pos-vec(0,.75,0)).id:find("slime"))) or false
    local bothBlocks = stairBlock or slabBlock

    oldhp = hp
    hp = player:getHealth() + player:getAbsorptionAmount()

    local posing = player:getPose()
    local stand = posing == "STANDING"
    local crouch = posing == "CROUCHING"
    local swim = posing == "SWIMMING"
    local gliding = posing == "FALL_FLYING"
    sleeping = posing == "SLEEPING"

    local velocity = player:getVelocity()
    local len = velocity:length()
    local walkingVal = 0.01
    local yvel = velocity.y
    local goingup = yvel > 0
    local goingdown = yvel < 0

    local pv = player:getVelocity():mul(1, 0, 1):normalize()
    local pl = models:partToWorldMatrix():applyDir(0,0,-1):mul(1, 0, 1):normalize()
    local fwd = pv:dot(pl)
    local backwards = fwd < -.8

    local sprint = player:isSprinting()
    local water = player:isInWater()
    local vehicle = player:getVehicle() ~= nil
    local grounded = player:isOnGround()
    local climbing = player:isClimbing() and not grounded
    local movingstate = (climbing and len > 0) or flying or vehicle or not stand
    local flystate = flying and not vehicle

    local jumping = host:isJumping()

    handedness = player:isLeftHanded()
    rightActive = handedness and "OFF_HAND" or "MAIN_HAND"
    leftActive = not handedness and "OFF_HAND" or "MAIN_HAND"
    local activeness = player:getActiveHand()
    local using = player:isUsingItem()

    local rightItem = player:getHeldItem(handedness)
    local leftItem = player:getHeldItem(not handedness)
    local usingR = activeness == rightActive and rightItem:getUseAction()
    local usingL = activeness == leftActive and leftItem:getUseAction()

    local crossR = rightItem.tag and rightItem.tag["Charged"] == 1
    local crossL = leftItem.tag and leftItem.tag["Charged"] == 1

    local drinkingR = using and usingR == "DRINK"
    local drinkingL = using and usingL == "DRINK"

    local eatingR = (using and usingR == "EAT")
    local eatingL = (using and usingL == "EAT")

    local blockingR = using and usingR == "BLOCK"
    local blockingL = using and usingL == "BLOCK"

    local bowingR = using and usingR == "BOW"
    local bowingL = using and usingL == "BOW"

    local spearR = using and usingR == "SPEAR"
    local spearL = using and usingL == "SPEAR"

    local spyglassR = using and usingR == "SPYGLASS"
    local spyglassL = using and usingL == "SPYGLASS"

    local hornR = using and usingR == "TOOT_HORN"
    local hornL = using and usingL == "TOOT_HORN"

    local loadingR = using and usingR == "CROSSBOW"
    local loadingL = using and usingL == "CROSSBOW"

    
    local rightHold = rightItem.id ~= "minecraft:air" and not (using or crossR or crossL)
    local leftHold = leftItem.id ~= "minecraft:air" and not (using or crossL or crossR)

    local flyupstate = flystate and goingup
    local flydownstate = flystate and goingdown
    local flysprintstate = flystate and sprint and yvel == 0
    local flywalkbackstate = flystate and backwards and yvel == 0 and len > walkingVal
    local flywalkstate = (flystate and len > walkingVal and yvel == 0 and not sprint and not backwards)
    local flyidlestate = (flystate and len < walkingVal and yvel == 0)

    local crawlstillstate = swim and not water and len < walkingVal
    local crawlstate = (swim and not water and len > walkingVal)

    local swimstate = (swim and water)

    local elytradownstate = gliding and goingdown
    local elytrastate = (gliding and goingup)

    local vehiclestate = vehicle and stand
    local sleepstate = sleeping

    local climbcrouchwalkstate = climbing and crouch and len > walkingVal
    local climbcrouchstate = (climbing and crouch and len < walkingVal)
    local climbdownstate = climbing and not crouch and len > 0 and goingdown
    local climbstillstate = (climbing and not crouch and len >= 0 and yvel == 0)
    local climbstate = (climbing and not crouch and len >= 0 and goingup)

    local crouchjumpdownstate = (crouch and goingdown and not climbing) and not bothBlocks
    local crouchjumpupstate = (crouch and goingup and not climbing) and not bothBlocks
    local crouchwalkbackstate = crouch and len > walkingVal and backwards and not climbing and not (crouchjumpupstate or crouchjumpdownstate)
    local crouchwalkstate = (crouch and len > walkingVal and not backwards and not climbing) and not (crouchjumpupstate or crouchjumpdownstate)
    local crouchstate =  (crouch and len < walkingVal and not climbing) and not (crouchjumpupstate or crouchjumpdownstate)

    local tridentstate = posing == "SPIN_ATTACK"

    local fallstate = not movingstate and yvel < -.6
    local jumpdownstate = ((not movingstate and goingdown and yvel > -.6) and (not sprint or sprint and water)) and not bothBlocks
    local jumpupstate =  ((not movingstate and goingup and not flying and (not sprint or sprint and water)) or (water and yvel >= 0 and not grounded and not movingstate and not sprint)) and not bothBlocks
    local sprintjumpdownstate = ((not movingstate and goingdown and yvel > -.6) and sprint and not water) and not bothBlocks
    local sprintjumpupstate =  ((not movingstate and goingup and not flying and sprint and not water)) and not bothBlocks
    local jumpingstate = jumpdownstate or jumpupstate or fallstate or jumping

    local sprintstate = not movingstate and sprint and stand and not water and not (sprintjumpupstate or sprintjumpdownstate or fallstate)
    local walkbackstate = not movingstate and not jumpingstate and len > walkingVal and not sprint and stand and backwards
    local walkstate = (not movingstate and not jumpingstate and len > walkingVal and (not sprint or sprint and water) and stand and not backwards)
    local idlestate = (not movingstate and len < walkingVal and (stand or swim and not water) and (yvel == 0 and ((grounded or slimeBlock) and not climbing)))

    local deadstate = hp == 0

    for _, path in pairs(bbmodels) do
        if oldhp > hp and hp ~= 0 and oldhp ~= 0 then
            if path.hurt then path.hurt:restart() end
        end

        local trueflyup = not deadstate and flyupstate
        local trueflydown = not deadstate and flydownstate
        local trueflysprint = not deadstate and flysprintstate
        local trueflywalkback = not deadstate and flywalkbackstate
        local trueflywalk = not deadstate and flywalkstate or (trueflysprint and not path.flysprint) or (trueflywalkback and not path.flywalkback)
        or (trueflyup and not path.flyup) or (trueflydown and not path.flydown)
        local truefly = not deadstate and flyidlestate or (trueflywalk and not path.flywalk)

        local truecrawlstill = not deadstate and crawlstillstate
        local truecrawl = not deadstate and crawlstate or (truecrawlstill and not path.crawlstill)

        local trueswim = not deadstate and swimstate or (truecrawl and not path.crawl)

        local trueelytradown  =not deadstate and elytradownstate
        local trueelytra = not deadstate and elytrastate or (trueelytradown and not path.elytradown)

        local truevehicle = not deadstate and vehiclestate
        local truesleep = not deadstate and sleepstate

        local trueclimbcrouchwalk = not deadstate and climbcrouchwalkstate
        local trueclimbcrouch = not deadstate and climbcrouchstate or (trueclimbcrouchwalk and not path.climbcrouchwalk)
        local trueclimbdown = not deadstate and climbdownstate
        local trueclimbstill = not deadstate and climbstillstate
        local trueclimb = not deadstate and climbstate or (trueclimbdown and not path.climbdown) or (trueclimbstill and not path.climbstill)

        local truecrouchjumpdown = not deadstate and crouchjumpdownstate
        local truecrouchjumpup = not deadstate and crouchjumpupstate or (truecrouchjumpdown and not path.crouchjumpdown)
        local truecrouchwalkback = not deadstate and crouchwalkbackstate
        local truecrouchwalk = not deadstate and crouchwalkstate or (truecrouchwalkback and not path.crouchwalkback) or (truecrouchjumpup and not path.crouchjumpup)
        local truecrouch = not deadstate and crouchstate or (truecrouchwalk and not path.crouchwalk) or (trueclimbcrouch and not path.climbcrouch)

        local truetrident = not deadstate and tridentstate

        local truefall = not deadstate and fallstate
        local truejumpdown = not deadstate and jumpdownstate or (truefall and not path.fall)
        local truejumpup = not deadstate and jumpupstate or (truejumpdown and not path.jumpdown) or (truetrident and not path.trident)
        local truesprintjumpdown = not deadstate and sprintjumpdownstate
        local truesprintjumpup = not deadstate and sprintjumpupstate or (truesprintjumpdown and not path.sprintjumpdown)

        local truesprint = not deadstate and sprintstate or (truesprintjumpup and not path.sprintjumpup)
        local truewalkback = not deadstate and walkbackstate
        local truewalk = not deadstate and walkstate or (truewalkback and not path.walkback) or (truesprint and not path.sprint) or (trueclimb and not path.climb) or (trueswim and not path.swim) or (trueelytra and not path.elytra)
        or (truejumpup and not path.jumpup)
        local trueidle = not deadstate and idlestate or (truesleep and not path.sleep) or (truevehicle and not path.vehicle) or (truefly and not path.fly)
        
        -- Exclusive animations
        if path.walk then path.walk:setPlaying(truewalk) end
        if path.idle then path.idle:setPlaying(trueidle) end
        if path.crouch then path.crouch:setPlaying(truecrouch) end
        if path.walkback then path.walkback:setPlaying(truewalkback) end
        if path.sprint then path.sprint:setPlaying(truesprint) end
        if path.crouchwalk then path.crouchwalk:setPlaying(truecrouchwalk) end
        if path.crouchwalkback then path.crouchwalkback:setPlaying(truecrouchwalkback) end
        if path.elytra then path.elytra:setPlaying(trueelytra) end
        if path.elytradown then path.elytradown:setPlaying(trueelytradown) end
        if path.fly then path.fly:setPlaying(truefly) end
        if path.flywalk then path.flywalk:setPlaying(trueflywalk) end
        if path.flywalkback then path.flywalkback:setPlaying(trueflywalkback) end
        if path.flysprint then path.flysprint:setPlaying(trueflysprint) end
        if path.flyup then path.flyup:setPlaying(trueflyup) end
        if path.flydown then path.flydown:setPlaying(trueflydown) end
        if path.vehicle then path.vehicle:setPlaying(truevehicle) end
        if path.sleep then path.sleep:setPlaying(truesleep) end
        if path.climb then path.climb:setPlaying(trueclimb) end
        if path.climbstill then path.climbstill:setPlaying(trueclimbstill) end
        if path.climbdown then path.climbdown:setPlaying(trueclimbdown) end
        if path.climbcrouch then path.climbcrouch:setPlaying(trueclimbcrouch) end
        if path.climbcrouchwalk then path.climbcrouchwalk:setPlaying(trueclimbcrouchwalk) end
        if path.swim then path.swim:setPlaying(trueswim) end
        if path.crawl then path.crawl:setPlaying(truecrawl) end
        if path.crawlstill then path.crawlstill:setPlaying(truecrawlstill) end
        if path.fall then path.fall:setPlaying(truefall) end
        if path.jumpup then path.jumpup:setPlaying(truejumpup) end
        if path.jumpdown then path.jumpdown:setPlaying(truejumpdown) end
        if path.sprintjumpup then path.sprintjumpup:setPlaying(truesprintjumpup) end
        if path.sprintjumpdown then path.sprintjumpdown:setPlaying(truesprintjumpdown) end
        if path.crouchjumpup then path.crouchjumpup:setPlaying(truecrouchjumpup) end
        if path.crouchjumpdown then path.crouchjumpdown:setPlaying(truecrouchjumpdown) end
        if path.trident then path.trident:setPlaying(truetrident) end
        if path.death then path.death:setPlaying(deadstate) end

        -- Inexclusive animations
        if path.eatingR then path.eatingR:setPlaying(not deadstate and eatingR or (drinkingR and not path.drinkingR)) end
        if path.eatingL then path.eatingL:setPlaying(not deadstate and eatingL or (drinkingL and not path.drinkingL)) end
        if path.drinkingR then path.drinkingR:setPlaying(not deadstate and drinkingR) end
        if path.drinkingL then path.drinkingL:setPlaying(not deadstate and drinkingL) end
        if path.blockingR then path.blockingR:setPlaying(not deadstate and blockingR) end
        if path.blockingL then path.blockingL:setPlaying(not deadstate and blockingL) end
        if path.bowR then path.bowR:setPlaying(not deadstate and bowingR) end
        if path.bowL then path.bowL:setPlaying(not deadstate and bowingL) end
        if path.crossbowR then path.crossbowR:setPlaying(not deadstate and crossR) end
        if path.crossbowL then path.crossbowL:setPlaying(not deadstate and crossL) end
        if path.loadingR then path.loadingR:setPlaying(not deadstate and loadingR) end
        if path.loadingL then path.loadingL:setPlaying(not deadstate and loadingL) end
        if path.spearR then path.spearR:setPlaying(not deadstate and spearR) end
        if path.spearL then path.spearL:setPlaying(not deadstate and spearL) end
        if path.spyglassR then path.spyglassR:setPlaying(not deadstate and spyglassR) end
        if path.spyglassL then path.spyglassL:setPlaying(not deadstate and spyglassL) end
        if path.hornR then path.hornR:setPlaying(not deadstate and hornR) end
        if path.hornL then path.hornL:setPlaying(not deadstate and hornL) end
        if path.holdR then path.holdR:setPlaying(not deadstate and rightHold) end
        if path.holdL then path.holdL:setPlaying(not deadstate and leftHold) end
    end
end

local function render()
    local rightSwing = player:getSwingArm() == rightActive and not sleeping
    local leftSwing = player:getSwingArm() == leftActive and not sleeping

    for _, path in pairs(bbmodels) do
        if path.attackR and not rightSwing then
            path.attackR:stop()
        end
        if path.attackL and not leftSwing then
            path.attackL:stop()
        end
        if path.mineR and not rightSwing then
            path.mineR:stop()
        end
        if path.mineL and not leftSwing then
            path.mineL:stop()
        end
        if path.useR and not rightSwing then
            path.useR:stop()
        end
        if path.useL and not leftSwing then
            path.useL:stop()
        end
    end
end

local GSAnimBlend
for _, key in ipairs(listFiles(nil,true)) do
    if key:find("GSAnimBlend$") then
        GSAnimBlend = require(key)
        break
    end
end
if GSAnimBlend then GSAnimBlend.safe = false end

local function blend(paths, time, itemTime)
    if not GSAnimBlend then return end
    for _, path in pairs(paths) do
        if path.walk then path.walk:blendTime(time) end
        if path.idle then path.idle:blendTime(time) end
        if path.crouch then path.crouch:blendTime(time) end
        if path.walkback then path.walkback:blendTime(time) end
        if path.sprint then path.sprint:blendTime(time) end
        if path.crouchwalk then path.crouchwalk:blendTime(time) end
        if path.crouchwalkback then path.crouchwalkback:blendTime(time) end
        if path.elytra then path.elytra:blendTime(time) end
        if path.elytradown then path.elytradown:blendTime(time) end
        if path.fly then path.fly:blendTime(time) end
        if path.flywalk then path.flywalk:blendTime(time) end
        if path.flywalkback then path.flywalkback:blendTime(time) end
        if path.flysprint then path.flysprint:blendTime(time) end
        if path.flyup then path.flyup:blendTime(time) end
        if path.flydown then path.flydown:blendTime(time) end
        if path.vehicle then path.vehicle:blendTime(time) end
        if path.sleep then path.sleep:blendTime(time) end
        if path.climb then path.climb:blendTime(time) end
        if path.climbstill then path.climbstill:blendTime(time) end
        if path.climbdown then path.climbdown:blendTime(time) end
        if path.climbcrouch then path.climbcrouch:blendTime(time) end
        if path.climbcrouchwalk then path.climbcrouchwalk:blendTime(time) end
        if path.swim then path.swim:blendTime(time) end
        if path.crawl then path.crawl:blendTime(time) end
        if path.crawlstill then path.crawlstill:blendTime(time) end
        if path.fall then path.fall:blendTime(time) end
        if path.jumpup then path.jumpup:blendTime(time) end
        if path.jumpdown then path.jumpdown:blendTime(time) end
        if path.sprintjumpup then path.sprintjumpup:blendTime(time) end
        if path.sprintjumpdown then path.sprintjumpdown:blendTime(time) end
        if path.crouchjumpup then path.crouchjumpup:blendTime(time) end
        if path.crouchjumpdown then path.crouchjumpdown:blendTime(time) end
        if path.trident then path.trident:blendTime(time) end
        if path.death then path.death:blendTime(time) end

        if path.eatingR then path.eatingR:blendTime(itemTime) end
        if path.eatingL then path.eatingL:blendTime(itemTime) end
        if path.drinkingR then path.drinkingR:blendTime(itemTime) end
        if path.drinkingL then path.drinkingL:blendTime(itemTime) end
        if path.blockingR then path.blockingR:blendTime(itemTime) end
        if path.blockingL then path.blockingL:blendTime(itemTime) end
        if path.bowR then path.bowR:blendTime(itemTime) end
        if path.bowL then path.bowL:blendTime(itemTime) end
        if path.crossbowR then path.crossbowR:blendTime(itemTime) end
        if path.crossbowL then path.crossbowL:blendTime(itemTime) end
        if path.loadingR then path.loadingR:blendTime(itemTime) end
        if path.loadingL then path.loadingL:blendTime(itemTime) end
        if path.spearR then path.spearR:blendTime(itemTime) end
        if path.spearL then path.spearL:blendTime(itemTime) end
        if path.spyglassR then path.spyglassR:blendTime(itemTime) end
        if path.spyglassL then path.spyglassL:blendTime(itemTime) end
        if path.hornR then path.hornR:blendTime(itemTime) end
        if path.hornL then path.hornL:blendTime(itemTime) end
        if path.attackR then path.attackR:blendTime(itemTime) end
        if path.attackL then path.attackL:blendTime(itemTime) end
        if path.mineR then path.mineR:blendTime(itemTime) end
        if path.mineL then path.mineL:blendTime(itemTime) end
        if path.useR then path.useR:blendTime(itemTime) end
        if path.useL then path.useL:blendTime(itemTime) end
        if path.holdR then path.holdR:blendTime(itemTime) end
        if path.holdL then path.holdL:blendTime(itemTime) end
    end
end

-- If you're choosing to edit this script, don't put anything beneath the return line

local init = false
local animMT = {__call = function(self, ...)
    local paths = {...}
    local should_blend = true
    if self.autoBlend ~= nil then should_blend = self.autoBlend end

    errors(paths)

    if should_blend then blend(paths, self.blendTime or 1.5, self.itemBlendTime or 1.5) end

    for _, v in ipairs(paths) do
        bbmodels[#bbmodels+1] = v
    end

    -- Init stuff.
    if init then return end
    events.TICK:register(tick)
    events.RENDER:register(render)
    animInit(paths)
    init = true
end}

return setmetatable({}, animMT)
