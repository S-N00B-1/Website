events.ENTITY_INIT:register(function()
    vanilla_model.PLAYER:setVisible(false)
end
)
