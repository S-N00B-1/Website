vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

renderer:offsetCameraPivot(0, 0.37, 0)

nameplate.ALL:setText("Mapbot")


local Voicelines = {
    "voicelines.freemap",
    "voicelines.hellomap",
    "voicelines.pleasemap",
    "voicelines.takemap"
}


FreeMap = keybinds:newKeybind("Random Voiceline", "key.keyboard.x")
ThankYou = keybinds:newKeybind("Thank You Voiceline", "key.keyboard.y")

function pings.FreeMap()
    if not player:isLoaded() then return end
    sounds:playSound(Voicelines[math.random(#Voicelines)], player:getPos())
end

function pings.ThankYou()
    if not player:isLoaded() then return end
    sounds:playSound("voicelines.pleaseenjoy", player:getPos())
end

function FreeMap.press() 
    pings.FreeMap()
end

function ThankYou.press() 
    pings.ThankYou()
end


function events.tick()
  local headrot = vanilla_model.HEAD:getOriginRot()
  models.model.root.MapBot.Hip.UpperHip.Chest.Neck.NotSkull:setRot(headrot)    
  models.model.root.MapBot.Hip.UpperHip.Chest.ArmR.LowerArmR.LeftItemPivot.Map:setVisible(false)
  models.model.root.MapBot.Hip.UpperHip.Chest.ArmL.LowerArmL.RightItemPivot.Map:setVisible(false)    
  if host:isHost() and renderer:isFirstPerson() then
    models.model.root.RightArm:setVisible(true)
    models.model.root.LeftArm:setVisible(true)
  else 
    models.model.root.LeftArm:setVisible(false)
    models.model.root.RightArm:setVisible(false)
  end    
  local holdingitem = player:getHeldItem().id == "minecraft:map" or player:getHeldItem().id == "minecraft:filled_map"
  local holdingitemoff = player:getHeldItem(true).id == "minecraft:map" or player:getHeldItem(true).id == "minecraft:filled_map"
  vanilla_model.HELD_ITEMS:setVisible(true)
  if player:isLeftHanded() then
    if holdingitem then
      models.model.root.MapBot.Hip.UpperHip.Chest.ArmR.LowerArmR.LeftItemPivot.Map:setVisible()
      vanilla_model.LEFT_ITEM:setVisible(false)
      host:setActionbar("GIVE MAP") 
    end
    if holdingitemoff then
      models.model.root.MapBot.Hip.UpperHip.Chest.ArmL.LowerArmL.RightItemPivot.Map:setVisible()
      vanilla_model.RIGHT_ITEM:setVisible(false)
      host:setActionbar("GIVE MAP")  
    end
  else
    if holdingitem then
      models.model.root.MapBot.Hip.UpperHip.Chest.ArmL.LowerArmL.RightItemPivot.Map:setVisible()
      vanilla_model.RIGHT_ITEM:setVisible(false)
      host:setActionbar("GIVE MAP") 
    end
    if holdingitemoff then
      models.model.root.MapBot.Hip.UpperHip.Chest.ArmR.LowerArmR.LeftItemPivot.Map:setVisible()
      vanilla_model.LEFT_ITEM:setVisible(false)
      host:setActionbar("GIVE MAP")  
    end
   end
   
end

