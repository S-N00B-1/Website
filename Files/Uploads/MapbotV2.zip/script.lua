-- + Made by Jimmy Hellp
-- + Thanks to KitCat for help with some of the code!
-- + V15 for rc14
-- + Automatically compatible with GSAnimBlend (just don't change the file name)

local avatarVer = "0.1.0-rc.14"
assert(
  client.compareVersions(client.getFiguraVersion(), avatarVer) > -1,
  "Your version of Figura is out of date for this animation template, the expected version is 0.1.0-rc.14"
)

local path = animations.model

WheelRotVar = 0

-- replace 'NAME_HERE' above with the name of your bbmodel WITHOUT the .bbmodel extension. For example... if your blockbench model is named jimmy replace NAME_HERE with jimmy
-- I recommend reading lines 43 through 94 as well, it's a list of animation names recognized and their behavior

local blendTime = 1.5
-- This is the blend time for GS Animation Blending considering body animations like idle, walk, crouch, etc

local itemBlendTime = 1.5
-- This is the blend time for GS Animation Blending considering hand animations like eating, drawing a bow, attacking, etc

------------------------ LIST OF ANIMATIONS BELOW ------------------------

--[[
    Only three of the animations are necessary for the script to function: idle, crouch, and walk. All other animations can be excluded without any harm being done to the script.
    Animations that are excluded might 'default' to another state. For example, if you exclude walkback, it will instead play the walk animation.

    List of animation names currently in this avatar:
    These need to be the animation name in blockbench for the associated state

    -- These are considered "exclusive" animations, meaning only one will play at a time
    idle
    walk
    walkback -- if it doesn't exist, walk plays instead
    sprint -- if it doesn't exist, walk plays instead
    crouch
    crouchwalk -- if it doesn't exist, crouch plays instead
    crouchwalkback -- if it doesn't exist, crouchwalk plays instead
    vehicle -- when riding any vehicle like a horse, pig, boat, etc. if it doesn't exist, idle plays instead
    jumpup -- if it doesn't exist, walk plays instead
    jumpdown -- if it doesn't exist, jumpup plays instead
    fall -- when falling from a great height. if it doesn't exist, jumpdown plays instead
    elytra -- when you're going up with an elytra, if elytradown is excluded it will also play when going down and act as a general using elytra animation. if it doesn't exist, walk plays instead
    elytradown -- what it says above, elytra plays if it doesn't exist
    fly -- when creative flying and idling. if it doesn't exist, idle plays instead
    flywalk -- when creative flying and walking, if it doesn't exist fly plays instead
    flywalkback -- when creative flying and walking backwards, if it doesn't exist, flywalk plays instead
    flysprint - when creative flying and sprinting, if it doesn't exist, flywalk plays instead
    flyup -- when creative flying and ascending, if it doesn't exist, flywalk plays instead
    flydown -- when creative flying and descending, if it doesn't exist, flywalk plays instead
    sleep -- if it doesn't exist, idle plays instead
    climb -- if it doesn't exist, walk plays instead
    swim -- if it doesn't exist, walk plays instead
    crawl -- when crawling and moving, if crawlstill is excluded this will always play when crawling. if it doesnt exist, swim plays instead
    crawlstill -- when in the crawling state while still. if it doesnt exist, crawl plays instead
    trident -- when doing the trident spin attack out of water. if it doesn't exist jumpup plays instead

    -- These are "inclusive" animations, meaning they can play at the same time as exclusive animations, and theoretically both hands could be working at the same time
    -- All of these have left and right versions, and are compatible with playing left handed
    eatingR / eatingL
    drinkingR / drinkingL -- if drinking is excluded it will default to eating
    blockingR / blockingL
    bowR / bowL -- for pulling back a bow
    crossbowR / crossbowL -- for holding a loaded crossbow
    loadingR / loadingL -- for loading the crossbow
    spearR / spearL -- for holding a trident up
    spyglassR / spyglassL
    hornR / hornL -- for the goat horn
    attackR / attackL -- for attacking
    mineR / mineL -- for mining, if mining is excluded it will play the attacking animation
    useR / useL -- for using, if using is excluded it will play the attacking animation

    -- These ones are special and will always play
    hurt -- this must be on the play once loop mode
    death

    -- If you want more animations to be added ping me and I'll make it happen if I have time
]]

-- This template doesn't come with any example emotes, I'll let you handle that, but you can use these tables to control how your custom emotes interact with the templated animations

------------------------ DON'T EDIT THIS UNLESS YOU KNOW WHAT YOU'RE DOING ------------------------ 

-- If you want an animation to stop all other animations in the template, add it to this table. 
-- These aren't exclusive to each other but could be made to be using the allVar, incluVar, and/or excluVar variables when deciding to play the new emote
local allAnims = {
    -- Example animation in table (except like... don't make it a comment):
    -- animations.example.example,
}

-- If you want an animation to stop all exclusive animations in the template (walking, idling, flying, swimming, etc), add it to this table
local excluAnims = {

}

-- If you want an animation to stop all inclusive animations in the template (eating, punching, using a bow or crossbow, etc), add it to this table
local incluAnims = {

}

assert(
    path,
    "The blockbench model wasn't found. Read line 14 in the script for instructions. If that doesn't work see my tutorial in the discord thread pins for hellp"
)

assert(
    path.walk,
    "The walk animation wasn't found, see my tutorial in the discord thread pins for hellp"
)

assert(
    path.idle,
    "The idle animation wasn't found, see my tutorial in the discord thread pins for hellp"
)

assert(
    path.crouch,
    "The crouch animation wasn't found, see my tutorial in the discord thread pins for hellp"
)

local hp = 20
local oldhp = 20
local animsTable={
    allVar = false,
    excluVar = false,
    incluVar = false
}

local handedness = false
local sleeping = false
local rightActive
local leftActive
local inclustate

local cFlying = false
local oldcFlying = cFlying
local flying = false
local flyTimer = 0

local dist = false
local oldDist = dist
local reach = 4.5
local reachTimer = 0

local attacka = false
local punch = false
local target = false
local targetEntity = false
local usey = false
local interact = false

function events.entity_init()
    hp = player:getHealth() + player:getAbsorptionAmount()
    oldhp = hp
end

function pings.JimmyAnims_cFly(x)
    flying = x
end

function pings.JimmyAnims_Distance(x)
    reach = x
end

function pings.attacking()
    punch = true
    targetEntity = target
end

function pings.calm()
    punch = false
end

function pings.using()
    interact = true
end

function pings.done()
    interact = false
end

local attack = keybinds:newKeybind("Attack",keybinds:getVanillaKey("key.attack"))
attack.press = pings.attacking
attack.release = pings.calm

local use = keybinds:newKeybind("Use",keybinds:getVanillaKey("key.use"))
use.press = pings.using
use.release = pings.done

function events.tick()
    for key, value in ipairs(allAnims) do
        if value:getPlayState() == "PLAYING" then
            animsTable.allVar = true
            break
        else
            animsTable.allVar = false
        end
    end
    for key, value in ipairs(excluAnims) do
        if value:getPlayState() == "PLAYING" then
            animsTable.excluVar = true
            break
        else
            animsTable.excluVar = false
        end
    end
    for key, value in ipairs(incluAnims) do
        if value:getPlayState() == "PLAYING" then
            animsTable.incluVar = true
            break
        else
            animsTable.incluVar = false
        end
    end

    if host:isHost() then
        cFlying = host:isFlying()
        if cFlying ~= oldcFlying then
            pings.JimmyAnims_cFly(cFlying)
        end
        oldcFlying = cFlying

        flyTimer = flyTimer + 1
        if flyTimer % 200 == 0 then
            pings.JimmyAnims_cFly(cFlying)
        end

        dist = host:getReachDistance()
        if dist ~= oldDist then
            pings.JimmyAnims_Distance(dist)
        end
        oldDist = dist

        reachTimer = reachTimer + 1
        if reachTimer % 200 == 0 then
            pings.JimmyAnims_Distance(dist)
        end

        attacka = attack:isPressed()
        usey = use:isPressed()
    end

    local stairBlock = (world.getBlockState(player:getPos()-vec(0,.3,0)).id:find("stair") or world.getBlockState(player:getPos()-vec(0,1,0)).id:find("stair")) or false
    local slabBlock = (world.getBlockState(player:getPos()-vec(0,.5,0)).id:find("slab" or world.getBlockState(player:getPos()-vec(0,.75,0)).id:find("slab"))) or false
    local bothBlocks = stairBlock or slabBlock

    oldhp = hp
    hp = player:getHealth() + player:getAbsorptionAmount()
    local posing = player:getPose()
    local stand = posing == "STANDING"
    local crouch = posing == "CROUCHING"
    local swim = posing == "SWIMMING"
    local gliding = posing == "FALL_FLYING"
    local velocity = player:getVelocity()
    local water = player:isInWater()
    local vehicle = player:getVehicle() ~= nil
    local climbing = player:isClimbing()
    local movingstate = (climbing and velocity:length() > 0) or flying or vehicle or not stand
    local sprint = player:isSprinting()
    local flystate = flying and not vehicle
    handedness = player:isLeftHanded()
    rightActive = handedness and "OFF_HAND" or "MAIN_HAND"
    leftActive = not handedness and "OFF_HAND" or "MAIN_HAND"
    local activeness = player:getActiveHand()
    local using = player:isUsingItem()
    local pv = player:getVelocity():mul(1, 0, 1):normalize()
    local pl = models:partToWorldMatrix():applyDir(0,0,-1):mul(1, 0, 1):normalize()
    local fwd = pv:dot(pl)
    local backwards = fwd < -.8
    sleeping = posing == "SLEEPING"
    local rightItem = player:getHeldItem(handedness)
    local leftItem = player:getHeldItem(not handedness)
    local usingR = activeness == rightActive and rightItem:getUseAction()
    local usingL = activeness == leftActive and leftItem:getUseAction()

    local crossR = rightItem.tag and rightItem.tag["Charged"] == 1
    local crossL = leftItem.tag and leftItem.tag["Charged"] == 1
    local drinkingR = using and usingR == "DRINK"
    local drinkingL = using and usingL == "DRINK"
    local eatingR = (using and usingR == "EAT") or (drinkingR and not path.drinkingR)
    local eatingL = (using and usingL == "EAT") or (drinkingL and not path.drinkingL)
    local blockingR = using and usingR == "BLOCK"
    local blockingL = using and usingL == "BLOCK"
    local bowingR = using and usingR == "BOW"
    local bowingL = using and usingL == "BOW"
    local spearR = using and usingR == "SPEAR"
    local spearL = using and usingL == "SPEAR"
    local spyglassR = using and usingR == "SPYGLASS"
    local spyglassL = using and usingL == "SPYGLASS"
    local hornR = using and usingR == "TOOT_HORN"
    local hornL = using and usingL == "TOOT_HORN"
    local loadingR = using and usingR == "CROSSBOW"
    local loadingL = using and usingL == "CROSSBOW"
    local flyupstate = flystate and velocity.y > 0
    local flydownstate = flystate and velocity.y < 0
    local flysprintstate = flystate and sprint and velocity.y == 0
    local flywalkbackstate = flystate and backwards and velocity.y == 0
    local flywalkstate = (flystate and velocity:length() > 0 and velocity.y == 0 and not sprint and not backwards) or (flysprintstate and not path.flysprint) or (flywalkbackstate and not path.flywalkback)
    or (flyupstate and not path.flyup) or (flydownstate and not path.flydown)
    local flyidlestate = (flystate and velocity:length() == 0) or (flywalkstate and not path.flywalk)
    local crouchwalkbackstate = crouch and backwards
    local crouchwalkstate = (crouch and velocity:length() > 0  and not backwards) or (crouchwalkbackstate and not path.crouchwalkback)
    local crouchstate =  (crouch and velocity:length() == 0) or (crouchwalkstate and not path.crouchwalk)
    local crawlstillstate = swim and not water and velocity:length() == 0
    local crawlstate = (swim and not water and velocity:length() > 0) or (crawlstillstate and not path.crawlstill)
    local swimstate = (swim and water) or (crawlstate and not path.crawl)
    local elytradownstate = gliding and velocity.y < 0
    local elytrastate = (gliding and velocity.y > 0) or (elytradownstate and not path.elytradown)
    local vehiclestate = vehicle
    local sleepstate = sleeping
    local climbstate = climbing and not crouch and velocity:length() > 0
    local tridentstate = posing == "SPIN_ATTACK"
    local fallstate = not movingstate and velocity.y < -.6
    local jumpdownstate = ((not movingstate and velocity.y < 0 and velocity.y > -.6)) and not bothBlocks or (fallstate and not path.fall)
    local jumpupstate =  ((not movingstate and velocity.y > 0 and not flying) or (tridentstate and not path.trident)) and not bothBlocks or (jumpdownstate and not path.jumpdown)
    local jumpingstate = jumpdownstate or jumpupstate or fallstate
    local deadstate = hp == 0
    local sprintstate = not movingstate and sprint and stand and not jumpingstate
    local walkbackstate = not movingstate and not jumpingstate and velocity:length() > 0 and not sprint and stand and backwards
    local walkstate = (not movingstate and not jumpingstate and velocity:length() > 0 and not sprint and stand and not backwards) 
    or (walkbackstate and not path.walkback) or (sprintstate and not path.sprint) or (climbstate and not path.climb) or (swimstate and not path.swim) or (elytrastate and not path.elytra)
    or (jumpupstate and not path.jumpup)
    local idlestate = (not movingstate and velocity:length() == 0 and (stand or swim and not water)) or (sleepstate and not path.sleep) or (vehiclestate and not path.vehicle) or (flyidlestate and not path.fly)

    if oldhp > hp and hp ~= 0 and oldhp ~= 0 then
        if path.hurt then path.hurt:restart() end
    end
    
    local exclustate = (not animsTable.allVar and not animsTable.excluVar) and not deadstate
    inclustate = not animsTable.allVar and not animsTable.incluVar

    -- Exclusive animations
    path.walk:setPlaying(exclustate and walkstate)
    path.idle:setPlaying(exclustate and idlestate)
    path.crouch:setPlaying(exclustate and crouchstate)
    if path.walkback then path.walkback:setPlaying(exclustate and walkbackstate) end
    if path.sprint then path.sprint:setPlaying(exclustate and sprintstate) end
    if path.crouchwalk then path.crouchwalk:setPlaying(exclustate and crouchwalkstate) end
    if path.crouchwalkback then path.crouchwalkback:setPlaying(exclustate and crouchwalkbackstate) end
    if path.elytra then path.elytra:setPlaying(exclustate and elytrastate) end
    if path.elytradown then path.elytradown:setPlaying(exclustate and elytradownstate) end
    if path.fly then path.fly:setPlaying(exclustate and flyidlestate) end
    if path.flywalk then path.flywalk:setPlaying(exclustate and flywalkstate) end
    if path.flywalkback then path.flywalkback:setPlaying(exclustate and flywalkbackstate) end
    if path.flysprint then path.flysprint:setPlaying(exclustate and flysprintstate) end
    if path.flyup then path.flyup:setPlaying(exclustate and flyupstate) end
    if path.flydown then path.flydown:setPlaying(exclustate and flydownstate) end
    if path.vehicle then path.vehicle:setPlaying(exclustate and vehiclestate) end
    if path.sleep then path.sleep:setPlaying(exclustate and sleepstate) end
    if path.climb then path.climb:setPlaying(exclustate and climbstate) end
    if path.swim then path.swim:setPlaying(exclustate and swimstate) end
    if path.crawl then path.crawl:setPlaying(exclustate and crawlstate) end
    if path.crawlstill then path.crawlstill:setPlaying(exclustate and crawlstillstate) end
    if path.fall then path.fall:setPlaying(exclustate and fallstate) end
    if path.jumpup then path.jumpup:setPlaying(exclustate and jumpupstate) end
    if path.jumpdown then path.jumpdown:setPlaying(exclustate and jumpdownstate) end
    if path.trident then path.trident:setPlaying(exclustate and tridentstate) end
    if path.death then path.death:setPlaying(deadstate) end

    -- Inexclusive animations
    if path.eatingR then path.eatingR:setPlaying(inclustate and eatingR) end
    if path.eatingL then path.eatingL:setPlaying(inclustate and eatingL) end
    if path.drinkingR then path.drinkingR:setPlaying(inclustate and drinkingR) end
    if path.drinkingL then path.drinkingL:setPlaying(inclustate and drinkingL) end
    if path.blockingR then path.blockingR:setPlaying(inclustate and blockingR) end
    if path.blockingL then path.blockingL:setPlaying(inclustate and blockingL) end
    if path.bowR then path.bowR:setPlaying(inclustate and bowingR) end
    if path.bowL then path.bowL:setPlaying(inclustate and bowingL) end
    if path.crossbowR then path.crossbowR:setPlaying(inclustate and crossR) end
    if path.crossbowL then path.crossbowL:setPlaying(inclustate and crossL) end
    if path.loadingR then path.loadingR:setPlaying(inclustate and loadingR) end
    if path.loadingL then path.loadingL:setPlaying(inclustate and loadingL) end
    if path.spearR then path.spearR:setPlaying(inclustate and spearR) end
    if path.spearL then path.spearL:setPlaying(inclustate and spearL) end
    if path.spyglassR then path.spyglassR:setPlaying(inclustate and spyglassR) end
    if path.spyglassL then path.spyglassL:setPlaying(inclustate and spyglassL) end
    if path.hornR then path.hornR:setPlaying(inclustate and hornR) end
    if path.hornL then path.hornL:setPlaying(inclustate and hornL) end

    -- START OF MAPBOT WHEELS SCRIPT
    if velocity:length() > 0 then 
        if backwards then
          models.model.root.MapBot.Hip.Wheels:setRot(0 + WheelRotVar,0,0)
          WheelRotVar = WheelRotVar + 8
        else
            models.model.root.MapBot.Hip.Wheels:setRot(0 + WheelRotVar,0,0)
            if player:isSprinting() then
              WheelRotVar = WheelRotVar - 15
            else
              WheelRotVar = WheelRotVar - 8
            end
        end
      end
      -- END OF MAPBOT WHEELS SCRIPT

end

function events.render(delta,context)
    local hitBlock = not (next(player:getTargetedBlock(true,reach):getTextures()) == nil)
    target = type(player:getTargetedEntity()) == "PlayerAPI" or type(player:getTargetedEntity()) == "LivingEntityAPI"
    local rightSwing = player:getSwingArm() == rightActive and not sleeping
    local leftSwing = player:getSwingArm() == leftActive and not sleeping
    local rightMine = punch and rightSwing and not handedness and hitBlock and not targetEntity
    local leftMine = punch and leftSwing and handedness and hitBlock and not targetEntity
    local rightUse = interact and rightSwing and not handedness and hitBlock and not targetEntity
    local leftUse = interact and leftSwing and handedness and hitBlock and not targetEntity
    local rightAttack = (punch and rightSwing and not handedness and (not hitBlock or targetEntity)) or (rightMine and not path.mineR) or (rightUse and not path.useR)
    local leftAttack = (punch and leftSwing and handedness and (not hitBlock or targetEntity)) or (leftMine and not path.mineL) or (rightUse and not path.useL)

    if path.attackR and (inclustate and rightAttack) then
        path.attackR:play()
    end
    if path.attackL and (inclustate and leftAttack) then
        path.attackL:play()
    end
    if path.mineR and (inclustate and rightMine) then
        path.mineR:play()
    end
    if path.mineL and (inclustate and leftMine) then
        path.mineL:play()
    end
    if path.useR and (inclustate and rightUse) then
        path.useR:play()
    end
    if path.useL and (inclustate and leftUse) then
        path.useL:play()
    end
end

for i, key in ipairs(listFiles(nil,true)) do
    if key:find("GSAnimBlend$") then
        require(key)
        path.walk:blendTime(blendTime)
        path.idle:blendTime(blendTime)
        path.crouch:blendTime(blendTime)
        if path.walkback then path.walkback:blendTime(blendTime) end
        if path.sprint then path.sprint:blendTime(blendTime) end
        if path.crouchwalk then path.crouchwalk:blendTime(blendTime) end
        if path.crouchwalkback then path.crouchwalkback:blendTime(blendTime) end
        if path.elytra then path.elytra:blendTime(blendTime) end
        if path.elytradown then path.elytradown:blendTime(blendTime) end
        if path.fly then path.fly:blendTime(blendTime) end
        if path.flywalk then path.flywalk:blendTime(blendTime) end
        if path.flywalkback then path.flywalkback:blendTime(blendTime) end
        if path.flysprint then path.flysprint:blendTime(blendTime) end
        if path.flyup then path.flyup:blendTime(blendTime) end
        if path.flydown then path.flydown:blendTime(blendTime) end
        if path.vehicle then path.vehicle:blendTime(blendTime) end
        if path.sleep then path.sleep:blendTime(blendTime) end
        if path.climb then path.climb:blendTime(blendTime) end
        if path.swim then path.swim:blendTime(blendTime) end
        if path.crawl then path.crawl:blendTime(blendTime) end
        if path.crawlstill then path.crawlstill:blendTime(blendTime) end
        if path.fall then path.fall:blendTime(blendTime) end
        if path.jumpup then path.jumpup:blendTime(blendTime) end
        if path.jumpdown then path.jumpdown:blendTime(blendTime) end
        if path.trident then path.trident:blendTime(blendTime) end
        if path.death then path.death:blendTime(blendTime) end
    
        -- Inexclusive animations
        if path.eatingR then path.eatingR:blendTime(itemBlendTime) end
        if path.eatingL then path.eatingL:blendTime(itemBlendTime) end
        if path.drinkingR then path.drinkingR:blendTime(itemBlendTime) end
        if path.drinkingL then path.drinkingL:blendTime(itemBlendTime) end
        if path.blockingR then path.blockingR:blendTime(itemBlendTime) end
        if path.blockingL then path.blockingL:blendTime(itemBlendTime) end
        if path.bowR then path.bowR:blendTime(itemBlendTime) end
        if path.bowL then path.bowL:blendTime(itemBlendTime) end
        if path.crossbowR then path.crossbowR:blendTime(itemBlendTime) end
        if path.crossbowL then path.crossbowL:blendTime(itemBlendTime) end
        if path.loadingR then path.loadingR:blendTime(itemBlendTime) end
        if path.loadingL then path.loadingL:blendTime(itemBlendTime) end
        if path.spearR then path.spearR:blendTime(itemBlendTime) end
        if path.spearL then path.spearL:blendTime(itemBlendTime) end
        if path.spyglassR then path.spyglassR:blendTime(itemBlendTime) end
        if path.spyglassL then path.spyglassL:blendTime(itemBlendTime) end
        if path.hornR then path.hornR:blendTime(itemBlendTime) end
        if path.hornL then path.hornL:blendTime(itemBlendTime) end
        if path.attackR then path.attackR:blendTime(itemBlendTime) end
        if path.attackL then path.attackL:blendTime(itemBlendTime) end
        if path.mineR then path.mineR:blendTime(itemBlendTime) end
        if path.mineL then path.mineL:blendTime(itemBlendTime) end
        if path.useR then path.useR:blendTime(itemBlendTime) end
        if path.useL then path.useL:blendTime(itemBlendTime) end
        break
    end
end


-- If you're choosing to edit this script, don't put anything beneath the return line

return animsTable