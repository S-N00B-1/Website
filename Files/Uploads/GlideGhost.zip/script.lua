events.ENTITY_INIT:register(function()
    vanilla_model.PLAYER:setVisible(false)
    vanilla_model.ARMOR:setVisible(false)
    vanilla_model.ELYTRA:setVisible(false)
    local speed = 0
end
)

function pings.speed(speedValue)
    particles:newParticle("wax_on", player:getPos()):setScale(1,1,1):setColor(1,math.min(1,speedValue),0)
    models.model:color(1,math.min(1,speedValue),0)
end

function events.tick()
  local speed = player:getVelocity():length()
  pings.speed(speed)
end
